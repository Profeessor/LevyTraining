bayesflow.attention module
==========================

.. automodule:: bayesflow.attention
   :members:
   :undoc-members:
   :show-inheritance:
