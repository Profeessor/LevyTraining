bayesflow.version module
========================

.. automodule:: bayesflow.version
   :members:
   :undoc-members:
   :show-inheritance:
