bayesflow.diagnostics module
============================

.. automodule:: bayesflow.diagnostics
   :members:
   :undoc-members:
   :show-inheritance:
