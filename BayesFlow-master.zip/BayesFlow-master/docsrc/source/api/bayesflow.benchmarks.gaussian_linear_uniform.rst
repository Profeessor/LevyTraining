bayesflow.benchmarks.gaussian\_linear\_uniform module
=====================================================

.. automodule:: bayesflow.benchmarks.gaussian_linear_uniform
   :members:
   :undoc-members:
   :show-inheritance:
