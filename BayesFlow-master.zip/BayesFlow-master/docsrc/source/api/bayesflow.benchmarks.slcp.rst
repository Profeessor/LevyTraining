bayesflow.benchmarks.slcp module
================================

.. automodule:: bayesflow.benchmarks.slcp
   :members:
   :undoc-members:
   :show-inheritance:
