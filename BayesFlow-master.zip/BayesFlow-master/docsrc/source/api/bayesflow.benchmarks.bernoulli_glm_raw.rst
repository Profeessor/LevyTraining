bayesflow.benchmarks.bernoulli\_glm\_raw module
===============================================

.. automodule:: bayesflow.benchmarks.bernoulli_glm_raw
   :members:
   :undoc-members:
   :show-inheritance:
