bayesflow.benchmarks.bernoulli\_glm module
==========================================

.. automodule:: bayesflow.benchmarks.bernoulli_glm
   :members:
   :undoc-members:
   :show-inheritance:
