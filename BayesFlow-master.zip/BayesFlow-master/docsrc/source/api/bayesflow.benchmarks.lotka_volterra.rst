bayesflow.benchmarks.lotka\_volterra module
===========================================

.. automodule:: bayesflow.benchmarks.lotka_volterra
   :members:
   :undoc-members:
   :show-inheritance:
