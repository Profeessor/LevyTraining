bayesflow.default\_settings module
==================================

.. automodule:: bayesflow.default_settings
   :members:
   :undoc-members:
   :show-inheritance:
