bayesflow.benchmarks.sir module
===============================

.. automodule:: bayesflow.benchmarks.sir
   :members:
   :undoc-members:
   :show-inheritance:
