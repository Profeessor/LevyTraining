bayesflow.coupling\_networks module
===================================

.. automodule:: bayesflow.coupling_networks
   :members:
   :undoc-members:
   :show-inheritance:
