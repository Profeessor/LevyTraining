bayesflow.benchmarks.slcp\_distractors module
=============================================

.. automodule:: bayesflow.benchmarks.slcp_distractors
   :members:
   :undoc-members:
   :show-inheritance:
