bayesflow.inference\_networks module
====================================

.. automodule:: bayesflow.inference_networks
   :members:
   :undoc-members:
   :show-inheritance:
