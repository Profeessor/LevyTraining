bayesflow.amortizers module
===========================

.. automodule:: bayesflow.amortizers
   :members:
   :undoc-members:
   :show-inheritance:
