bayesflow.summary\_networks module
==================================

.. automodule:: bayesflow.summary_networks
   :members:
   :undoc-members:
   :show-inheritance:
