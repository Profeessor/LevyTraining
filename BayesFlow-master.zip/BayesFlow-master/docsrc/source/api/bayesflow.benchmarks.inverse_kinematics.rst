bayesflow.benchmarks.inverse\_kinematics module
===============================================

.. automodule:: bayesflow.benchmarks.inverse_kinematics
   :members:
   :undoc-members:
   :show-inheritance:
