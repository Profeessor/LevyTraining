bayesflow.benchmarks.two\_moons module
======================================

.. automodule:: bayesflow.benchmarks.two_moons
   :members:
   :undoc-members:
   :show-inheritance:
