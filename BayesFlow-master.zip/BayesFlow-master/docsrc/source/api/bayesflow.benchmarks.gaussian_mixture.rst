bayesflow.benchmarks.gaussian\_mixture module
=============================================

.. automodule:: bayesflow.benchmarks.gaussian_mixture
   :members:
   :undoc-members:
   :show-inheritance:
