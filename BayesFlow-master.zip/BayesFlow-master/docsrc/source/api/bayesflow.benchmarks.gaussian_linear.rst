bayesflow.benchmarks.gaussian\_linear module
============================================

.. automodule:: bayesflow.benchmarks.gaussian_linear
   :members:
   :undoc-members:
   :show-inheritance:
